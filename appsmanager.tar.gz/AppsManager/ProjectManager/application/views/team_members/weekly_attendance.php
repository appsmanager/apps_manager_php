<table id="weekly-attendance-table" class="display" cellspacing="0" width="100%">            
</table>
<script type="text/javascript">
    $(document).ready(function () {
        loadMembersAttendanceTable("#weekly-attendance-table", "weekly");
    });
</script>