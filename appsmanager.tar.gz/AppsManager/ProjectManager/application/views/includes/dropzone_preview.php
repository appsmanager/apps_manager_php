<div class="post-file-dropzone-scrollbar hide">
    <div class="post-file-previews clearfix b-t"> 
        <div class="post-file-upload-row dz-image-preview dz-success dz-complete pull-left">
            <div class="preview" style="width:85px;">
                <img data-dz-thumbnail class="upload-thumbnail-sm" />
                <span data-dz-remove="" class="delete">×</span>
                <div class="progress progress-striped upload-progress-sm active m0" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <div class="progress-bar progress-bar-success" style="width:0%;" data-dz-uploadprogress></div>
                </div>
            </div>
        </div>
    </div>
</div>