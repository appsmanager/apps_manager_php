<div class="panel panel-success">
    <div class="panel-body ">
        <div class="widget-icon">
            <i class="fa fa-check-circle"></i>
        </div>
        <div class="widget-details">
            <h1><?php echo $project_completed; ?></h1>
            <?php echo lang("projects_completed"); ?>
        </div>
    </div>
</div>