<div class="panel">
    <?php
        $this->load->view("projects/comments/comment_form");
   
        $this->load->view("projects/comments/comment_list"); 
        ?>
</div>
